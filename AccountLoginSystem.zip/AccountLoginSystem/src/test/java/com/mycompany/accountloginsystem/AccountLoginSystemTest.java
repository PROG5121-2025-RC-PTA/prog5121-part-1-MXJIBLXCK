/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.accountloginsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class AccountLoginSystemTest {
    
    public AccountLoginSystemTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of isValidUsername method, of class AccountLoginSystem.
     */
    @Test
    public void testIsValidUsername() {
        System.out.println("isValidUsername");
        String username = "";
        boolean expResult = false;
        boolean result = AccountLoginSystem.isValidUsername(username);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of isValidPassword method, of class AccountLoginSystem.
     */
    @Test
    public void testIsValidPassword() {
        System.out.println("isValidPassword");
        String password = "";
        boolean expResult = false;
        boolean result = AccountLoginSystem.isValidPassword(password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of isValidPhoneNumber method, of class AccountLoginSystem.
     */
    @Test
    public void testIsValidPhoneNumber() {
        System.out.println("isValidPhoneNumber");
        String phone = "";
        boolean expResult = false;
        boolean result = AccountLoginSystem.isValidPhoneNumber(phone);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of createAccount method, of class AccountLoginSystem.
     */
    @Test
    public void testCreateAccount() {
        System.out.println("createAccount");
        AccountLoginSystem.createAccount();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of login method, of class AccountLoginSystem.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        AccountLoginSystem.login();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of main method, of class AccountLoginSystem.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        AccountLoginSystem.main(args);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
