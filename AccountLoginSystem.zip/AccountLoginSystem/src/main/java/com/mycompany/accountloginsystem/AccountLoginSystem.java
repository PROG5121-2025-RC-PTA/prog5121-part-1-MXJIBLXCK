/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.accountloginsystem;
import javax.swing.JOptionPane;
import java.util.HashMap;
import java.util.regex.Pattern;
/**
 *
 * @author OfentseBahula(ST10468444)
 */

class User { // Stores the user info
    String username;
    String password;
    String phone;

    User(String username, String password, String phone) {
        this.username = username;
        this.password = password;
        this.phone = phone;
    }
}

public class AccountLoginSystem {
    static HashMap<String, User> userDatabase = new HashMap<>();

    public static boolean isValidUsername(String username) { // Conditions the Username should meet 
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public static boolean isValidPassword(String password) { // Conditions the password has to meet
        if (password == null || password.length() < 8)
            return false;

        boolean hasUppercase = Pattern.compile("[A-Z]").matcher(password).find();
        boolean hasNumber = Pattern.compile("[0-9]").matcher(password).find();
        boolean hasSpecialChar = Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();
        return hasUppercase && hasNumber && hasSpecialChar;
    }

    public static boolean isValidPhoneNumber(String phone) { // Conditions that have to be met by the user's password
        return phone != null && phone.matches("^\\+27\\d{9}$");
    }

    public static void createAccount() { // The user can now create the account 
        String username = JOptionPane.showInputDialog(null,
                "Enter username (should contain _ and a maximum of 5 characters):",
                "Create Account", JOptionPane.QUESTION_MESSAGE);

        if (username != null) {
        } else {
            return;
        }

        if (!isValidUsername(username)) { // If the user entered incorrect username
            JOptionPane.showMessageDialog(null, "Invalid username. Please try again.",
                    "Create Account", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (userDatabase.containsKey(username)) { // If the user entered a registerd username to register again
            JOptionPane.showMessageDialog(null,
                    "Username already exists. Please try a different username.",
                    "Create Account", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String password = JOptionPane.showInputDialog(null, // User enters password
                "Enter password (minimum 8 characters, must include uppercase, number, special character):",
                "Create Account", JOptionPane.QUESTION_MESSAGE);

        if (!isValidPassword(password)) { // If the user entered incorrect password
            JOptionPane.showMessageDialog(null, "Invalid password . Please try again.",
                    "Create Account", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String phone = JOptionPane.showInputDialog(null, // User enters Phone Number
                "Enter phone number (e.g. +27610251061):",
                "Create Account", JOptionPane.QUESTION_MESSAGE);

        if (!isValidPhoneNumber(phone)) {
            JOptionPane.showMessageDialog(null, "Invalid phone number. Please try again.",
                    "Create Account", JOptionPane.ERROR_MESSAGE);
            return;
        }

        userDatabase.put(username, new User(username, password, phone));
        JOptionPane.showMessageDialog(null, "Your account was been successfully created!",
                "Create Account", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // User Logs in 
    public static void login() {
        String username = JOptionPane.showInputDialog(null,
                "Enter username:",
                "Login", JOptionPane.QUESTION_MESSAGE);

        if (username == null)
            return;

        String password = JOptionPane.showInputDialog(null,
                "Enter password:",
                "Login", JOptionPane.QUESTION_MESSAGE);

        if (password == null)
            return;

        User user = userDatabase.get(username);

        if (user != null && user.password.equals(password)) { // User Login successful
            JOptionPane.showMessageDialog(null,
                    "Login was successful!\nWelcome. It's great to see you again, " + user.username + "\nPhone number: " + user.phone,
                    "Login Successful", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, //User Login unsuccessful
                    "Invalid username or password. Please try again.",
                    "Login Unsuccessful", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        while (true) {
            String[] options = { "Create Account", "Login", "Exit" };
            int choice = JOptionPane.showOptionDialog(null,
                    "===>Account -_- Login<=== ",
                    "Account Login System",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    options,
                    options[0]);

            if (choice == 0) {
                createAccount();
            } else if (choice == 1) {
                login();
            } else if (choice == 2 || choice == JOptionPane.CLOSED_OPTION) {
                JOptionPane.showMessageDialog(null, "Goodbye!", "Account System", JOptionPane.INFORMATION_MESSAGE);
                return;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid choice.", "Account System", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}